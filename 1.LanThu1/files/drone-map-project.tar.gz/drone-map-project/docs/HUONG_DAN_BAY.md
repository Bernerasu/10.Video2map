# ✈️ Hướng dẫn Bay Drone cho DroneMap

## Trước khi bay

### Chuẩn bị thiết bị
- [ ] Drone đã sạc pin đầy (≥80%)
- [ ] Thẻ nhớ còn trống đủ (≥16GB)
- [ ] GPS lock ≥10 vệ tinh (đợi 1-2 phút trước khi bay)
- [ ] Jetson Orin Nano đã bật và kết nối
- [ ] Router WiFi portable đã bật (nếu dùng)
- [ ] 4 đèn GCP đã đặt và bật (nếu dùng)

### Đặt đèn GCP (tùy chọn — tăng độ chính xác)
1. Chọn 4 vị trí trống, không bị cây che
2. Khoảng cách giữa các đèn: 30-50m
3. ĐO và GHI LẠI tất cả 6 khoảng cách (AB, AC, AD, BC, BD, CD)
4. Bật 4 đèn — kiểm tra nhấp nháy đúng tần số
5. Ghi lại vị trí đèn A vào sổ (nếu cần đối chiếu sau)

### Kiểm tra thời tiết
- ✅ Gió < 20 km/h
- ✅ Không mưa
- ✅ Tầm nhìn > 1 km
- ❌ KHÔNG bay khi có sấm chớp

---

## Phương pháp bay

### Pattern "Cắt cỏ" (Khuyến nghị)

```
Bay theo hình zigzag, mỗi đường song song:

    Bắt đầu ─────────────────→
    ←─────────────────────────
    ──────────────────────────→
    ←─────────────────────────
    ──────────────────────────→ Kết thúc

    |← ──── overlap 60% ──── →|
```

### Thông số theo độ cao

| Độ cao | Tốc độ | Overlap ngang | Coverage/frame | Dùng cho |
|--------|--------|---------------|----------------|----------|
| **50m** | 3-5 m/s | 60% | 173×130m | Chi tiết cao, tìm người |
| **100m** | 5-8 m/s | 60% | 346×260m | Cân bằng |
| **150m** | 5-8 m/s | 60% | 520×390m | Diện tích lớn |
| **300m** | 5-8 m/s | 50% | 1040×780m | Tổng quan |

### Bay cho cứu hộ (tìm người)
- **Độ cao: 50-80m** (người hiện rõ ~15-30 pixel)
- Tốc độ: 3-5 m/s (chậm = rõ hơn)
- Góc camera: 90° (nhìn thẳng xuống)
- Ưu tiên bay qua: mái nhà, bãi đất cao, nơi có thể có người tụ tập

---

## Quy trình bay

### Bước 1: Cất cánh
1. Đặt drone ở vị trí GCP (nếu có) hoặc điểm dễ nhớ
2. Bật quay video (HD, 30fps)
3. Cất cánh → lên độ cao target

### Bước 2: Bay qua vùng GCP (bắt buộc nếu dùng GCP)
- Bay thẳng phía trên 4 đèn GCP
- Giữ ổn định 3-5 giây (để camera thu đủ chu kỳ nhấp nháy)

### Bước 3: Bắt đầu pattern cắt cỏ
- Bay theo đường thẳng
- Cuối đường → rẽ 180° → bay ngược lại
- Dịch sang ngang: khoảng 40% chiều rộng frame (overlap 60%)

### Bước 4: Kết thúc
- Bay lại qua vùng GCP (close loop — giảm drift)
- Tắt quay video
- Hạ cánh

---

## Sau khi bay

1. Tắt drone, lấy thẻ nhớ
2. Copy file MP4 vào Jetson:
   ```bash
   # Qua USB:
   cp /media/sdcard/DJI_0001.MP4 /opt/dronemap/input/

   # Hoặc qua mạng:
   scp video.mp4 jetson@192.168.1.100:/opt/dronemap/input/
   ```
3. Chạy pipeline:
   ```bash
   cd /path/to/drone-map
   source venv/bin/activate
   python3 src/pipeline.py --video /opt/dronemap/input/DJI_0001.MP4
   ```
4. Mở trình duyệt: `http://jetson-ip:8080`

---

## Ước tính diện tích theo pin

| Drone | Pin | Thời gian bay | Diện tích ở 100m | Diện tích ở 50m |
|-------|-----|---------------|-------------------|-----------------|
| DJI Mini 4 | 2590mAh | ~30 phút | ~0.5 km² | ~0.2 km² |
| DJI Air 3 | 4241mAh | ~40 phút | ~0.8 km² | ~0.3 km² |
| DJI Mavic 3 | 5000mAh | ~45 phút | ~1.0 km² | ~0.4 km² |

*Ước tính với tốc độ 5 m/s, overlap 60%, có gió nhẹ*

---

## An toàn

⚠️ **Luôn tuân thủ quy định bay drone tại Việt Nam:**
- Đăng ký drone với cơ quan quản lý
- Không bay gần sân bay, khu quân sự
- Không bay trên đám đông
- Giữ tầm nhìn trực tiếp với drone (VLOS)
- **Trong thiên tai**: phối hợp với ban chỉ huy cứu hộ trước khi bay
