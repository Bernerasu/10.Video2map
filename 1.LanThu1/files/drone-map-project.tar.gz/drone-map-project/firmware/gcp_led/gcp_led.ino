/*
 * DroneMap — Firmware đèn GCP (Ground Control Point)
 *
 * Flash firmware này lên 4 Arduino Nano, mỗi cái 1 tần số khác nhau.
 *
 * ĐÈN A: BLINK_FREQ = 1   (1 Hz)
 * ĐÈN B: BLINK_FREQ = 2   (2 Hz)
 * ĐÈN C: BLINK_FREQ = 3   (3 Hz)
 * ĐÈN D: BLINK_FREQ = 5   (5 Hz)
 *
 * === THAY ĐỔI GIÁ TRỊ NÀY CHO MỖI ĐÈN ===
 */

#define BLINK_FREQ  1   // Hz — ĐỔI GIÁ TRỊ NÀY: 1, 2, 3, hoặc 5

// Chân LED — nối LED 10W qua MOSFET hoặc relay
#define LED_PIN  13     // Dùng pin 13 (có LED onboard) hoặc pin khác

// Tính toán
#define HALF_PERIOD_MS  (1000 / (2 * BLINK_FREQ))

void setup() {
    pinMode(LED_PIN, OUTPUT);
}

void loop() {
    digitalWrite(LED_PIN, HIGH);
    delay(HALF_PERIOD_MS);
    digitalWrite(LED_PIN, LOW);
    delay(HALF_PERIOD_MS);
}

/*
 * === HƯỚNG DẪN ĐẤU NỐI ===
 *
 * Cho LED công suất cao (10W):
 *
 *   Arduino Pin 13 ──→ Gate MOSFET (IRFZ44N)
 *   MOSFET Drain ──→ LED (-) cathode
 *   LED (+) anode ──→ +12V
 *   MOSFET Source ──→ GND
 *   Arduino GND ──→ GND chung
 *
 * Cho LED nhỏ (test):
 *
 *   Arduino Pin 13 ──→ Resistor 220Ω ──→ LED (+) ──→ GND
 *
 * === FLASH CHO MỖI ĐÈN ===
 *
 *   1. Mở Arduino IDE
 *   2. Thay BLINK_FREQ = 1 (cho đèn A)
 *   3. Upload lên Arduino Nano #1
 *   4. Thay BLINK_FREQ = 2 (cho đèn B)
 *   5. Upload lên Arduino Nano #2
 *   6. Lặp lại cho đèn C (3) và D (5)
 *
 * === KIỂM TRA ===
 *
 *   Đèn A: sáng 0.5s, tắt 0.5s (chậm nhất)
 *   Đèn B: sáng 0.25s, tắt 0.25s
 *   Đèn C: sáng 0.167s, tắt 0.167s
 *   Đèn D: sáng 0.1s, tắt 0.1s (nhanh nhất)
 *
 *   → Mắt thường phân biệt được 4 đèn
 *   → Camera 30fps phân tích FFT phân biệt chính xác
 */
