"""
Module 8: Tile Generator
Cắt mosaic thành tile pyramid cho web map

Input:  mosaic image + metadata
Output: tiles/{z}/{x}/{y}.webp (hoặc png/jpg)
"""

import cv2
import numpy as np
import os
import math
from pathlib import Path
from tqdm import tqdm


class TileGenerator:
    def __init__(self, config: dict):
        self.tile_size = config.get("tile_size", 256)
        self.format = config.get("format", "webp")
        self.quality = config.get("quality", 80)
        self.zoom_min = config.get("zoom_min", 10)
        self.zoom_max = config.get("zoom_max", 20)

    def generate(self, mosaic: np.ndarray, metadata: dict,
                 output_dir: str, gps_available: bool = False,
                 frames: list = None):
        """
        Tạo tile pyramid từ mosaic.

        Nếu có GPS: tạo tiles theo Slippy Map convention (TMS/XYZ)
        Nếu không GPS: tạo tiles đơn giản (local coordinates)
        """
        out = Path(output_dir)

        if gps_available and frames:
            self._generate_geo_tiles(mosaic, metadata, frames, out)
        else:
            self._generate_local_tiles(mosaic, out)

        # Tạo metadata file cho web client
        self._write_metadata(mosaic, metadata, out, gps_available, frames)

    def _generate_local_tiles(self, mosaic: np.ndarray, output_dir: Path):
        """Tạo tiles đơn giản (không có GPS) — dùng cho preview"""
        h, w = mosaic.shape[:2]

        # Tính số zoom levels cần thiết
        max_dim = max(w, h)
        max_zoom = max(0, int(math.ceil(math.log2(max_dim / self.tile_size))))
        min_zoom = max(0, max_zoom - 4)

        total_tiles = 0

        for z in range(min_zoom, max_zoom + 1):
            scale = 2 ** (max_zoom - z)
            scaled_w = max(1, w // scale)
            scaled_h = max(1, h // scale)

            # Resize mosaic cho zoom level này
            if scale > 1:
                scaled = cv2.resize(mosaic, (scaled_w, scaled_h),
                                    interpolation=cv2.INTER_AREA)
            else:
                scaled = mosaic

            # Cắt thành tiles
            num_x = math.ceil(scaled_w / self.tile_size)
            num_y = math.ceil(scaled_h / self.tile_size)

            for tx in range(num_x):
                for ty in range(num_y):
                    x1 = tx * self.tile_size
                    y1 = ty * self.tile_size
                    x2 = min(x1 + self.tile_size, scaled_w)
                    y2 = min(y1 + self.tile_size, scaled_h)

                    tile = np.zeros((self.tile_size, self.tile_size, 3), dtype=np.uint8)
                    tile[:y2 - y1, :x2 - x1] = scaled[y1:y2, x1:x2]

                    # Bỏ tile hoàn toàn đen
                    if np.mean(tile) < 2:
                        continue

                    # Lưu tile
                    tile_dir = output_dir / str(z) / str(tx)
                    tile_dir.mkdir(parents=True, exist_ok=True)

                    tile_path = tile_dir / f"{ty}.{self.format}"
                    self._save_tile(tile, str(tile_path))
                    total_tiles += 1

        print(f"  📦 {total_tiles} tiles (zoom {min_zoom}-{max_zoom})")

    def _generate_geo_tiles(self, mosaic: np.ndarray, metadata: dict,
                            frames: list, output_dir: Path):
        """Tạo geo-referenced tiles (Slippy Map TMS)"""
        # Tính bounding box từ GPS frames
        lats = [f["lat"] for f in frames if f.get("lat") is not None]
        lons = [f["lon"] for f in frames if f.get("lon") is not None]

        if not lats or not lons:
            self._generate_local_tiles(mosaic, output_dir)
            return

        min_lat, max_lat = min(lats), max(lats)
        min_lon, max_lon = min(lons), max(lons)

        # Expand bbox slightly
        lat_margin = (max_lat - min_lat) * 0.1
        lon_margin = (max_lon - min_lon) * 0.1
        min_lat -= lat_margin
        max_lat += lat_margin
        min_lon -= lon_margin
        max_lon += lon_margin

        h, w = mosaic.shape[:2]

        # Tính zoom range phù hợp
        zoom_max = self._calc_max_zoom(min_lat, max_lat, min_lon, max_lon, w, h)
        zoom_min = max(1, zoom_max - 5)

        total_tiles = 0

        for z in range(zoom_min, zoom_max + 1):
            # Tính tile range cho zoom level này
            x_min, y_max = self._deg2tile(min_lat, min_lon, z)
            x_max, y_min = self._deg2tile(max_lat, max_lon, z)

            for tx in range(x_min, x_max + 1):
                for ty in range(y_min, y_max + 1):
                    # Tọa độ GPS của tile
                    tile_lat1, tile_lon1 = self._tile2deg(tx, ty, z)
                    tile_lat2, tile_lon2 = self._tile2deg(tx + 1, ty + 1, z)

                    # Pixel range trên mosaic
                    px1 = int((tile_lon1 - min_lon) / (max_lon - min_lon) * w)
                    py1 = int((max_lat - tile_lat1) / (max_lat - min_lat) * h)
                    px2 = int((tile_lon2 - min_lon) / (max_lon - min_lon) * w)
                    py2 = int((max_lat - tile_lat2) / (max_lat - min_lat) * h)

                    # Clamp
                    px1 = max(0, min(w, px1))
                    py1 = max(0, min(h, py1))
                    px2 = max(0, min(w, px2))
                    py2 = max(0, min(h, py2))

                    if px2 <= px1 or py2 <= py1:
                        continue

                    region = mosaic[py1:py2, px1:px2]
                    if np.mean(region) < 2:
                        continue

                    tile = cv2.resize(region, (self.tile_size, self.tile_size),
                                      interpolation=cv2.INTER_AREA)

                    tile_dir = output_dir / str(z) / str(tx)
                    tile_dir.mkdir(parents=True, exist_ok=True)
                    tile_path = tile_dir / f"{ty}.{self.format}"
                    self._save_tile(tile, str(tile_path))
                    total_tiles += 1

        print(f"  📦 {total_tiles} geo-tiles (zoom {zoom_min}-{zoom_max})")
        print(f"  📍 Bbox: [{min_lat:.6f}, {min_lon:.6f}] → [{max_lat:.6f}, {max_lon:.6f}]")

    def _save_tile(self, tile: np.ndarray, path: str):
        """Lưu tile với format và quality đã chọn"""
        if self.format == "webp":
            cv2.imwrite(path, tile, [cv2.IMWRITE_WEBP_QUALITY, self.quality])
        elif self.format == "jpg":
            cv2.imwrite(path, tile, [cv2.IMWRITE_JPEG_QUALITY, self.quality])
        else:
            cv2.imwrite(path, tile)

    def _write_metadata(self, mosaic, metadata, output_dir, gps_available, frames):
        """Ghi metadata cho web client"""
        import json

        meta = {
            "tile_size": self.tile_size,
            "format": self.format,
            "gps_available": gps_available,
            "mosaic_size": [mosaic.shape[1], mosaic.shape[0]],
        }

        if gps_available and frames:
            lats = [f["lat"] for f in frames if f.get("lat")]
            lons = [f["lon"] for f in frames if f.get("lon")]
            if lats and lons:
                meta["bounds"] = {
                    "south": min(lats), "north": max(lats),
                    "west": min(lons), "east": max(lons),
                }
                meta["center"] = {
                    "lat": (min(lats) + max(lats)) / 2,
                    "lon": (min(lons) + max(lons)) / 2,
                }

        meta_path = output_dir / "metadata.json"
        with open(meta_path, "w") as f:
            json.dump(meta, f, indent=2)

    @staticmethod
    def _deg2tile(lat, lon, zoom):
        """GPS coordinates → tile index"""
        lat_rad = math.radians(lat)
        n = 2 ** zoom
        x = int((lon + 180.0) / 360.0 * n)
        y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
        return x, y

    @staticmethod
    def _tile2deg(x, y, zoom):
        """Tile index → GPS coordinates"""
        n = 2 ** zoom
        lon = x / n * 360.0 - 180.0
        lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
        lat = math.degrees(lat_rad)
        return lat, lon

    @staticmethod
    def _calc_max_zoom(min_lat, max_lat, min_lon, max_lon, w, h):
        """Tính zoom level tối đa phù hợp với resolution"""
        lat_span = max_lat - min_lat
        lon_span = max_lon - min_lon

        for z in range(20, 0, -1):
            tiles_x = (lon_span / 360.0) * (2 ** z)
            if tiles_x * 256 <= w * 2:
                return z
        return 15
