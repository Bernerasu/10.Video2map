"""
Module 5: Incremental Stitcher
Ghép ảnh panorama/mosaic từ keyframes

Input:  keyframes (có thể có GPS)
Output: mosaic image + metadata
"""

import cv2
import numpy as np
from tqdm import tqdm


class IncrementalStitcher:
    def __init__(self, config: dict):
        self.feature_detector = config.get("feature_detector", "orb")
        self.max_features = config.get("max_features", 5000)
        self.match_threshold = config.get("match_threshold", 0.7)
        self.blend_method = config.get("blend_method", "multiband")
        self.use_gpu = config.get("use_gpu", True)
        self.max_mosaic_mb = config.get("max_mosaic_size_mb", 2048)

        # Khởi tạo detector
        self._init_detector()

    def _init_detector(self):
        """Khởi tạo feature detector"""
        if self.feature_detector == "orb":
            self.detector = cv2.ORB_create(nfeatures=self.max_features)
            self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        elif self.feature_detector == "sift":
            self.detector = cv2.SIFT_create(nfeatures=self.max_features)
            self.matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
        elif self.feature_detector == "akaze":
            self.detector = cv2.AKAZE_create()
            self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        else:
            self.detector = cv2.ORB_create(nfeatures=self.max_features)
            self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)

    def stitch(self, frames: list) -> tuple:
        """
        Ghép ảnh incremental.

        Returns:
            mosaic (np.ndarray): Ảnh mosaic
            metadata (dict): Thông tin về mosaic
        """
        if len(frames) < 2:
            if len(frames) == 1:
                return frames[0]["image"], {"num_frames": 1, "transforms": []}
            return None, None

        print(f"  🧩 Ghép {len(frames)} frames...")

        # Bước 1: Tính feature cho tất cả frames
        print(f"  Detecting features ({self.feature_detector.upper()})...")
        features = []
        for f in tqdm(frames, desc="  Features", unit="frame"):
            gray = cv2.cvtColor(f["image"], cv2.COLOR_BGR2GRAY)
            kp, des = self.detector.detectAndCompute(gray, None)
            features.append({"keypoints": kp, "descriptors": des})

        # Bước 2: Ghép incremental
        # Frame đầu tiên = anchor
        anchor = frames[0]["image"]
        h, w = anchor.shape[:2]

        # Canvas lớn hơn — ước tính kích thước mosaic
        canvas_scale = 3  # Canvas gấp 3 lần frame
        canvas_h = h * canvas_scale
        canvas_w = w * canvas_scale

        # Kiểm tra memory limit
        canvas_mb = (canvas_h * canvas_w * 3) / (1024 * 1024)
        if canvas_mb > self.max_mosaic_mb:
            scale = np.sqrt(self.max_mosaic_mb / canvas_mb)
            canvas_h = int(canvas_h * scale)
            canvas_w = int(canvas_w * scale)
            print(f"  ⚠️  Giảm canvas để fit RAM: {canvas_w}x{canvas_h}")

        mosaic = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)
        mosaic_mask = np.zeros((canvas_h, canvas_w), dtype=np.uint8)

        # Đặt frame đầu ở giữa canvas
        offset_x = (canvas_w - w) // 2
        offset_y = (canvas_h - h) // 2

        mosaic[offset_y:offset_y + h, offset_x:offset_x + w] = anchor
        mosaic_mask[offset_y:offset_y + h, offset_x:offset_x + w] = 255

        # Homography tích lũy — bắt đầu từ offset
        H_accumulated = np.eye(3, dtype=np.float64)
        H_accumulated[0, 2] = offset_x
        H_accumulated[1, 2] = offset_y

        transforms = [H_accumulated.copy()]
        stitch_count = 1
        fail_count = 0

        pbar = tqdm(range(1, len(frames)), desc="  Stitching", unit="frame")

        for i in pbar:
            # Match features giữa frame i và frame i-1
            H_relative = self._match_and_compute_homography(
                features[i - 1], features[i]
            )

            if H_relative is None:
                fail_count += 1
                pbar.set_postfix({"fail": fail_count})
                continue

            # Tích lũy homography
            H_accumulated = H_accumulated @ H_relative

            # Warp frame vào mosaic
            warped = cv2.warpPerspective(
                frames[i]["image"], H_accumulated, (canvas_w, canvas_h)
            )
            warped_mask = cv2.warpPerspective(
                np.ones((h, w), dtype=np.uint8) * 255,
                H_accumulated, (canvas_w, canvas_h)
            )

            # Blend vào mosaic
            self._blend_into_mosaic(mosaic, mosaic_mask, warped, warped_mask)

            transforms.append(H_accumulated.copy())
            stitch_count += 1
            pbar.set_postfix({"ok": stitch_count, "fail": fail_count})

        print(f"  ✅ Ghép thành công: {stitch_count}/{len(frames)} frames")

        # Crop mosaic — bỏ vùng đen xung quanh
        mosaic, crop_offset = self._crop_mosaic(mosaic, mosaic_mask)

        metadata = {
            "num_frames": stitch_count,
            "transforms": transforms,
            "canvas_offset": (offset_x, offset_y),
            "crop_offset": crop_offset,
            "original_frame_size": (w, h),
        }

        return mosaic, metadata

    def _match_and_compute_homography(self, feat1: dict, feat2: dict) -> np.ndarray:
        """Match features giữa 2 frames và tính homography"""
        des1 = feat1["descriptors"]
        des2 = feat2["descriptors"]
        kp1 = feat1["keypoints"]
        kp2 = feat2["keypoints"]

        if des1 is None or des2 is None:
            return None

        if len(des1) < 10 or len(des2) < 10:
            return None

        # KNN match
        try:
            matches = self.matcher.knnMatch(des1, des2, k=2)
        except cv2.error:
            return None

        # Lowe's ratio test
        good_matches = []
        for match_pair in matches:
            if len(match_pair) == 2:
                m, n = match_pair
                if m.distance < self.match_threshold * n.distance:
                    good_matches.append(m)

        if len(good_matches) < 10:
            return None

        # Tính homography
        src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
        dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

        H, mask = cv2.findHomography(dst_pts, src_pts, cv2.RANSAC, 5.0)

        if H is None:
            return None

        # Kiểm tra homography hợp lệ (không quá méo)
        if not self._is_valid_homography(H):
            return None

        return H

    def _is_valid_homography(self, H: np.ndarray) -> bool:
        """Kiểm tra homography có hợp lệ không (tránh degenerate cases)"""
        det = np.linalg.det(H[:2, :2])
        if det < 0.1 or det > 10:
            return False

        # Kiểm tra scale không quá lớn
        if abs(H[0, 2]) > 5000 or abs(H[1, 2]) > 5000:
            return False

        return True

    def _blend_into_mosaic(self, mosaic, mosaic_mask, warped, warped_mask):
        """Blend frame đã warp vào mosaic"""
        # Vùng chỉ có frame mới (chưa có trong mosaic)
        new_only = (warped_mask > 0) & (mosaic_mask == 0)
        mosaic[new_only] = warped[new_only]

        # Vùng overlap — trung bình đơn giản
        overlap = (warped_mask > 0) & (mosaic_mask > 0)
        if np.any(overlap):
            mosaic[overlap] = cv2.addWeighted(
                mosaic, 0.5, warped, 0.5, 0
            )[overlap]

        # Cập nhật mask
        mosaic_mask[warped_mask > 0] = 255

    def _crop_mosaic(self, mosaic, mask) -> tuple:
        """Crop bỏ vùng đen xung quanh mosaic"""
        coords = cv2.findNonZero(mask)
        if coords is None:
            return mosaic, (0, 0)

        x, y, w, h = cv2.boundingRect(coords)

        # Thêm margin nhỏ
        margin = 10
        x = max(0, x - margin)
        y = max(0, y - margin)
        w = min(mosaic.shape[1] - x, w + 2 * margin)
        h = min(mosaic.shape[0] - y, h + 2 * margin)

        cropped = mosaic[y:y + h, x:x + w]
        return cropped, (x, y)
