"""
Module 7: Georeferencer
Gán tọa độ GPS cho mosaic → xuất GeoTIFF

Input:  mosaic + GPS-tagged frames + stitch metadata
Output: GeoTIFF file
"""

import cv2
import numpy as np


class Georeferencer:
    def __init__(self, config: dict):
        self.output_crs = config.get("output_crs", "EPSG:4326")
        self.method = config.get("method", "gps")

    def georeference(self, mosaic: np.ndarray, mosaic_meta: dict,
                     frames: list, output_path: str):
        """
        Tạo GeoTIFF từ mosaic.

        Sử dụng GPS data từ frames + homography transforms
        để tính affine transform cho toàn bộ mosaic.
        """
        # Thu thập GPS points đã biết
        gps_points = []
        for i, f in enumerate(frames):
            if f.get("lat") is not None and i < len(mosaic_meta.get("transforms", [])):
                H = mosaic_meta["transforms"][i]
                # Center của frame sau khi transform
                h, w = mosaic_meta.get("original_frame_size", (1920, 1080))
                center_px = np.array([w / 2, h / 2, 1.0])
                center_mosaic = H @ center_px
                center_mosaic /= center_mosaic[2]

                # Trừ crop offset
                cx, cy = mosaic_meta.get("crop_offset", (0, 0))
                mx = center_mosaic[0] - cx
                my = center_mosaic[1] - cy

                gps_points.append({
                    "pixel_x": mx,
                    "pixel_y": my,
                    "lat": f["lat"],
                    "lon": f["lon"],
                })

        if len(gps_points) < 3:
            print("  ⚠️  Không đủ GPS points (<3) để georef")
            # Lưu mosaic thường
            cv2.imwrite(output_path.replace(".tif", ".png"), mosaic)
            return

        # Tính affine transform: pixel → GPS
        src = np.array([[p["pixel_x"], p["pixel_y"]] for p in gps_points], dtype=np.float64)
        dst = np.array([[p["lon"], p["lat"]] for p in gps_points], dtype=np.float64)

        # Least squares affine
        # [lon]   [a b c] [px]
        # [lat] = [d e f] [py]
        #                  [1 ]
        n = len(src)
        A = np.zeros((2 * n, 6))
        b = np.zeros(2 * n)

        for i in range(n):
            A[2 * i] = [src[i, 0], src[i, 1], 1, 0, 0, 0]
            A[2 * i + 1] = [0, 0, 0, src[i, 0], src[i, 1], 1]
            b[2 * i] = dst[i, 0]      # lon
            b[2 * i + 1] = dst[i, 1]  # lat

        params, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        a, bb, c, d, e, f = params

        # GeoTransform: [origin_x, pixel_size_x, rotation_x, origin_y, rotation_y, pixel_size_y]
        geo_transform = [c, a, bb, f, d, e]

        # Lưu GeoTIFF
        self._write_geotiff(mosaic, geo_transform, output_path)

        # Tính GSD (ground sampling distance)
        gsd_lon = abs(a)  # degrees per pixel
        gsd_lat = abs(e)
        gsd_m = gsd_lon * 111320  # approximate meters per degree at equator
        print(f"  📐 GSD ước tính: {gsd_m:.2f} m/pixel")

    def _write_geotiff(self, mosaic: np.ndarray, geo_transform: list,
                       output_path: str):
        """Ghi GeoTIFF bằng GDAL"""
        try:
            from osgeo import gdal, osr

            h, w = mosaic.shape[:2]
            bands = mosaic.shape[2] if len(mosaic.shape) > 2 else 1

            driver = gdal.GetDriverByName("GTiff")
            ds = driver.Create(
                output_path, w, h, bands, gdal.GDT_Byte,
                options=["COMPRESS=DEFLATE", "TILED=YES"]
            )

            ds.SetGeoTransform(geo_transform)

            srs = osr.SpatialReference()
            srs.ImportFromEPSG(4326)
            ds.SetProjection(srs.ExportToWkt())

            if bands >= 3:
                # OpenCV BGR → GeoTIFF RGB
                for i in range(3):
                    band = ds.GetRasterBand(i + 1)
                    band.WriteArray(mosaic[:, :, 2 - i])  # BGR → RGB
            else:
                ds.GetRasterBand(1).WriteArray(mosaic)

            ds.FlushCache()
            ds = None
            print(f"  💾 GeoTIFF saved: {output_path}")

        except ImportError:
            print("  ⚠️  GDAL không available — lưu mosaic thường + metadata")
            cv2.imwrite(output_path.replace(".tif", ".png"), mosaic)

            # Lưu geo metadata ra file riêng
            import json
            meta_path = output_path.replace(".tif", "_geo.json")
            with open(meta_path, "w") as mf:
                json.dump({
                    "geo_transform": geo_transform,
                    "crs": self.output_crs,
                    "size": [w, h],
                }, mf, indent=2)
            print(f"  💾 Geo metadata: {meta_path}")
