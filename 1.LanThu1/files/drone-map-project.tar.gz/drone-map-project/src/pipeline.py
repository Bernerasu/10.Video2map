#!/usr/bin/env python3
"""
DroneMap — Pipeline chính
Xử lý video drone → bản đồ 2D trên web

Sử dụng:
    python3 src/pipeline.py --video video.mp4
    python3 src/pipeline.py --video video.mp4 --gps gps.srt
    python3 src/pipeline.py --video video.mp4 --detect person,vehicle,flood
"""

import argparse
import sys
import time
import os
import yaml
from pathlib import Path

# Thêm src/ vào path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from video_parser import VideoParser
from gps_sync import GPSSync
from undistort import CameraUndistort
from stitcher import IncrementalStitcher
from ai_detector import AIDetector
from georeferencer import Georeferencer
from tile_generator import TileGenerator


def load_config(config_path: str = None) -> dict:
    """Load cấu hình từ file YAML"""
    if config_path is None:
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config", "pipeline.yaml"
        )
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def print_banner():
    print("""
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   🗺️  DroneMap — Bản đồ Cứu hộ Thời gian Thực      ║
║                                                      ║
║   Mã nguồn mở • Miễn phí • Cho cứu hộ cứu nạn      ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
""")


def run_pipeline(args, config: dict):
    """Chạy toàn bộ pipeline"""
    output_dir = Path(config["output"]["dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    total_start = time.time()
    timings = {}

    # =========================================================
    # BƯỚC 1: Parse video → keyframes
    # =========================================================
    print("\n" + "=" * 60)
    print("📹 BƯỚC 1/7: Trích xuất keyframes từ video...")
    print("=" * 60)

    t0 = time.time()
    parser = VideoParser(config["video"])
    frames = parser.extract_keyframes(args.video)
    timings["1_parse"] = time.time() - t0

    print(f"  ✅ Trích xuất {len(frames)} keyframes ({timings['1_parse']:.1f}s)")

    if len(frames) == 0:
        print("  ❌ Không trích xuất được frame nào. Kiểm tra file video.")
        sys.exit(1)

    # =========================================================
    # BƯỚC 2: GPS sync
    # =========================================================
    print("\n" + "=" * 60)
    print("📡 BƯỚC 2/7: Đồng bộ GPS...")
    print("=" * 60)

    t0 = time.time()
    gps_sync = GPSSync(config["gps"])

    if args.gps:
        frames = gps_sync.sync_from_file(frames, args.gps)
        gps_available = True
        print(f"  ✅ GPS sync từ file: {args.gps}")
    else:
        # Thử đọc GPS từ video metadata
        frames = gps_sync.sync_from_video(frames, args.video)
        gps_available = any(f.get("lat") is not None for f in frames)
        if gps_available:
            print(f"  ✅ GPS đọc từ video metadata")
        else:
            print(f"  ⚠️  Không có GPS — bản đồ sẽ không có tọa độ thực")

    timings["2_gps"] = time.time() - t0

    # =========================================================
    # BƯỚC 3: Camera undistortion
    # =========================================================
    print("\n" + "=" * 60)
    print("📷 BƯỚC 3/7: Sửa méo lens...")
    print("=" * 60)

    t0 = time.time()
    if config["camera"]["undistort"]:
        undistort = CameraUndistort(config["camera"])
        frames = undistort.process(frames)
        print(f"  ✅ Undistort {len(frames)} frames")
    else:
        print(f"  ⏭️  Bỏ qua (undistort=false trong config)")
    timings["3_undistort"] = time.time() - t0

    # =========================================================
    # BƯỚC 4: AI Detection (nếu bật)
    # =========================================================
    detections = []

    if args.detect:
        print("\n" + "=" * 60)
        print("🤖 BƯỚC 4/7: AI Detection...")
        print("=" * 60)

        t0 = time.time()
        targets = [t.strip() for t in args.detect.split(",")]
        ai_config = config["ai"].copy()
        ai_config["enabled"] = True
        ai_config["targets"] = targets

        if "flood" in targets:
            ai_config["flood_detection"] = True
            targets.remove("flood")

        detector = AIDetector(ai_config)
        detections = detector.detect_all(frames)
        timings["4_ai"] = time.time() - t0

        total_detections = sum(len(d.get("objects", [])) for d in detections)
        print(f"  ✅ Phát hiện {total_detections} đối tượng ({timings['4_ai']:.1f}s)")
    else:
        print("\n  ⏭️  BƯỚC 4/7: AI Detection — bỏ qua (dùng --detect để bật)")
        timings["4_ai"] = 0

    # =========================================================
    # BƯỚC 5: Stitching → Mosaic
    # =========================================================
    print("\n" + "=" * 60)
    print("🧩 BƯỚC 5/7: Ghép ảnh (stitching)...")
    print("=" * 60)

    t0 = time.time()
    stitcher = IncrementalStitcher(config["stitcher"])
    mosaic, mosaic_metadata = stitcher.stitch(frames)
    timings["5_stitch"] = time.time() - t0

    if mosaic is not None:
        h, w = mosaic.shape[:2]
        print(f"  ✅ Mosaic: {w}x{h} pixels ({timings['5_stitch']:.1f}s)")
    else:
        print("  ❌ Stitching thất bại. Kiểm tra video (cần overlap ≥30%).")
        sys.exit(1)

    # =========================================================
    # BƯỚC 6: Georeferencing
    # =========================================================
    print("\n" + "=" * 60)
    print("🌍 BƯỚC 6/7: Georeferencing...")
    print("=" * 60)

    t0 = time.time()
    georef = Georeferencer(config["georef"])
    geotiff_path = output_dir / "mosaic" / "mosaic.tif"
    geotiff_path.parent.mkdir(parents=True, exist_ok=True)

    if gps_available:
        georef.georeference(mosaic, mosaic_metadata, frames, str(geotiff_path))
        print(f"  ✅ GeoTIFF: {geotiff_path}")
    else:
        # Không có GPS — lưu mosaic thường
        import cv2
        cv2.imwrite(str(geotiff_path.with_suffix(".png")), mosaic)
        print(f"  ⚠️  Không có GPS — lưu mosaic không có tọa độ")

    timings["6_georef"] = time.time() - t0

    # =========================================================
    # BƯỚC 7: Tile Generation
    # =========================================================
    print("\n" + "=" * 60)
    print("🗂️  BƯỚC 7/7: Tạo map tiles...")
    print("=" * 60)

    t0 = time.time()
    tile_gen = TileGenerator(config["tiles"])
    tiles_dir = output_dir / "tiles"
    tile_gen.generate(mosaic, mosaic_metadata, str(tiles_dir),
                      gps_available=gps_available, frames=frames)
    timings["7_tiles"] = time.time() - t0

    # Đếm tiles
    tile_count = sum(1 for _ in tiles_dir.rglob("*.webp")) + \
                 sum(1 for _ in tiles_dir.rglob("*.png")) + \
                 sum(1 for _ in tiles_dir.rglob("*.jpg"))
    print(f"  ✅ {tile_count} tiles tạo xong ({timings['7_tiles']:.1f}s)")

    # =========================================================
    # Lưu detections (nếu có)
    # =========================================================
    if detections:
        import json
        det_path = output_dir / "detections" / "detections.geojson"
        det_path.parent.mkdir(parents=True, exist_ok=True)

        geojson = _detections_to_geojson(detections, frames, gps_available)
        with open(det_path, "w") as f:
            json.dump(geojson, f, ensure_ascii=False, indent=2)
        print(f"\n  📍 Detections: {det_path}")

    # =========================================================
    # Tổng kết
    # =========================================================
    total_time = time.time() - total_start
    print("\n" + "=" * 60)
    print("✅ HOÀN TẤT!")
    print("=" * 60)
    print(f"""
  ⏱️  Tổng thời gian: {total_time:.1f}s ({total_time/60:.1f} phút)

  📊 Chi tiết:
     Parse video:    {timings['1_parse']:.1f}s
     GPS sync:       {timings['2_gps']:.1f}s
     Undistort:      {timings['3_undistort']:.1f}s
     AI Detection:   {timings['4_ai']:.1f}s
     Stitching:      {timings['5_stitch']:.1f}s
     Georef:         {timings['6_georef']:.1f}s
     Tile gen:       {timings['7_tiles']:.1f}s

  🌐 Xem bản đồ: http://localhost:8080
     (hoặc http://<jetson-ip>:8080 từ thiết bị khác)
""")


def _detections_to_geojson(detections, frames, gps_available):
    """Chuyển detections thành GeoJSON"""
    features = []

    for det in detections:
        frame_id = det.get("frame_id", 0)
        frame = frames[frame_id] if frame_id < len(frames) else {}

        for obj in det.get("objects", []):
            feature = {
                "type": "Feature",
                "properties": {
                    "class": obj["class"],
                    "confidence": round(obj["confidence"], 2),
                    "frame_id": frame_id,
                    "timestamp": frame.get("timestamp", 0),
                    "pixel_x": obj["center"][0],
                    "pixel_y": obj["center"][1],
                },
                "geometry": None
            }

            # Nếu có GPS → gán tọa độ (ước lượng)
            if gps_available and frame.get("lat") is not None:
                feature["geometry"] = {
                    "type": "Point",
                    "coordinates": [
                        frame.get("lon", 0),
                        frame.get("lat", 0)
                    ]
                }

            features.append(feature)

    return {
        "type": "FeatureCollection",
        "features": features
    }


def main():
    print_banner()

    parser = argparse.ArgumentParser(
        description="DroneMap — Bản đồ cứu hộ thời gian thực từ flycam"
    )
    parser.add_argument(
        "--video", required=True,
        help="Đường dẫn file video MP4"
    )
    parser.add_argument(
        "--gps", default=None,
        help="File GPS (SRT, CSV, TLOG). Tự động đọc từ video nếu không chỉ định."
    )
    parser.add_argument(
        "--detect", default=None,
        help="Bật AI detection. Ví dụ: --detect person,vehicle,flood"
    )
    parser.add_argument(
        "--config", default=None,
        help="File cấu hình YAML (mặc định: config/pipeline.yaml)"
    )
    parser.add_argument(
        "--output", default=None,
        help="Thư mục output (mặc định: /opt/dronemap/output)"
    )

    args = parser.parse_args()

    # Load config
    config = load_config(args.config)

    if args.output:
        config["output"]["dir"] = args.output

    # Kiểm tra file video
    if not os.path.exists(args.video):
        print(f"❌ Không tìm thấy file video: {args.video}")
        sys.exit(1)

    # Chạy pipeline
    run_pipeline(args, config)


if __name__ == "__main__":
    main()
