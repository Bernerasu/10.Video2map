"""
Module 9: Web Server
Serve bản đồ + detections qua web

Truy cập: http://jetson-ip:8080
"""

import os
import json
from pathlib import Path
from flask import Flask, render_template, send_from_directory, jsonify
from flask_socketio import SocketIO

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), "web", "templates"),
    static_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), "web", "static"),
)
app.config["SECRET_KEY"] = "dronemap-rescue"

socketio = SocketIO(app, cors_allowed_origins="*")

OUTPUT_DIR = os.environ.get("DRONEMAP_OUTPUT", "/opt/dronemap/output")


@app.route("/")
def index():
    """Trang chính — giao diện bản đồ"""
    return render_template("index.html")


@app.route("/tiles/<path:filepath>")
def serve_tile(filepath):
    """Serve map tiles"""
    tiles_dir = os.path.join(OUTPUT_DIR, "tiles")
    return send_from_directory(tiles_dir, filepath)


@app.route("/api/metadata")
def get_metadata():
    """Metadata bản đồ (bounds, center, zoom levels)"""
    meta_path = os.path.join(OUTPUT_DIR, "tiles", "metadata.json")
    if os.path.exists(meta_path):
        with open(meta_path) as f:
            return jsonify(json.load(f))
    return jsonify({"error": "No metadata yet"})


@app.route("/api/detections")
def get_detections():
    """AI detections (GeoJSON)"""
    det_path = os.path.join(OUTPUT_DIR, "detections", "detections.geojson")
    if os.path.exists(det_path):
        with open(det_path) as f:
            return jsonify(json.load(f))
    return jsonify({"type": "FeatureCollection", "features": []})


@app.route("/api/status")
def get_status():
    """Trạng thái hệ thống"""
    tiles_dir = Path(OUTPUT_DIR) / "tiles"
    tile_count = sum(1 for _ in tiles_dir.rglob("*.*")) if tiles_dir.exists() else 0

    det_path = Path(OUTPUT_DIR) / "detections" / "detections.geojson"
    det_count = 0
    if det_path.exists():
        with open(det_path) as f:
            data = json.load(f)
            det_count = len(data.get("features", []))

    return jsonify({
        "status": "ready" if tile_count > 0 else "waiting",
        "tiles": tile_count,
        "detections": det_count,
    })


def notify_update(update_type: str, data: dict = None):
    """Gửi thông báo realtime đến web clients"""
    socketio.emit("map_update", {
        "type": update_type,
        "data": data or {}
    })


if __name__ == "__main__":
    print(f"""
╔══════════════════════════════════════════════════════╗
║  🗺️  DroneMap Web Server                            ║
║  Output: {OUTPUT_DIR:<42s} ║
╚══════════════════════════════════════════════════════╝
""")
    socketio.run(app, host="0.0.0.0", port=5000, debug=False, allow_unsafe_werkzeug=True)
