"""
Module 4: GCP Detector
Phát hiện đèn LED nhấp nháy làm Ground Control Points

Input:  video frames (chuỗi liên tục, không phải keyframes)
Output: tọa độ pixel của 4 đèn GCP trên frame
"""

import cv2
import numpy as np


class GCPDetector:
    def __init__(self, config: dict):
        self.frequencies = config.get("blink_frequencies", {
            "A": 1.0, "B": 2.0, "C": 3.0, "D": 5.0
        })
        self.distances = config.get("distances", {})
        self.num_points = config.get("num_points", 4)

    def detect_from_video(self, video_path: str, fps: float,
                          analysis_duration_sec: float = 3.0) -> dict:
        """
        Phân tích đoạn video để tìm đèn nhấp nháy.

        Thuật toán:
        1. Thu thập N frames liên tiếp
        2. Với mỗi pixel, phân tích brightness theo thời gian
        3. FFT → tìm tần số dominant
        4. Pixel nào có tần số khớp với GCP → đó là đèn
        """
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return {}

        num_frames = int(fps * analysis_duration_sec)
        frames_gray = []

        for _ in range(num_frames):
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Downscale để giảm compute
            gray = cv2.resize(gray, (0, 0), fx=0.25, fy=0.25)
            frames_gray.append(gray.astype(np.float32))

        cap.release()

        if len(frames_gray) < 10:
            print("  ⚠️  Không đủ frames để phân tích GCP")
            return {}

        # Stack thành 3D array: (time, height, width)
        stack = np.stack(frames_gray, axis=0)

        # Tìm bright spots có temporal variation
        temporal_std = np.std(stack, axis=0)
        mean_brightness = np.mean(stack, axis=0)

        # Mask: điểm sáng + có biến thiên (nhấp nháy)
        bright_mask = mean_brightness > np.percentile(mean_brightness, 95)
        blink_mask = temporal_std > np.percentile(temporal_std, 95)
        candidate_mask = bright_mask & blink_mask

        # Tìm connected components
        candidate_u8 = candidate_mask.astype(np.uint8) * 255
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            candidate_u8, connectivity=8
        )

        # Phân tích tần số cho mỗi candidate
        gcps = {}
        for i in range(1, num_labels):  # Skip background (0)
            cx, cy = centroids[i]

            # Lấy temporal signal tại centroid
            y, x = int(cy), int(cx)
            signal = stack[:, y, x]

            # FFT
            freq = self._analyze_frequency(signal, fps)

            # Match với tần số đã biết
            label = self._match_frequency(freq)
            if label:
                # Scale tọa độ lại (đã downscale 4x)
                gcps[label] = {
                    "pixel": (int(cx * 4), int(cy * 4)),
                    "frequency": freq,
                    "confidence": 0.8  # TODO: tính confidence thực
                }

        return gcps

    def _analyze_frequency(self, signal: np.ndarray, fps: float) -> float:
        """Phân tích tần số dominant bằng FFT"""
        # Normalize
        signal = signal - np.mean(signal)
        if np.std(signal) < 1:
            return 0.0

        # FFT
        n = len(signal)
        fft = np.abs(np.fft.rfft(signal))
        freqs = np.fft.rfftfreq(n, d=1.0 / fps)

        # Bỏ DC component (index 0) và tần số rất thấp
        fft[0] = 0
        if len(fft) > 1:
            fft[1] = 0

        # Tìm peak frequency
        peak_idx = np.argmax(fft)
        return freqs[peak_idx]

    def _match_frequency(self, freq: float, tolerance: float = 0.3) -> str:
        """Match tần số detected với tần số GCP đã biết"""
        for label, target_freq in self.frequencies.items():
            if abs(freq - target_freq) < tolerance:
                return label
        return None

    def compute_homography(self, gcps: dict) -> np.ndarray:
        """
        Tính homography từ pixel coordinates → real world coordinates.
        Dùng khoảng cách đã đo giữa các GCP.
        """
        if len(gcps) < 4:
            return None

        # Tính tọa độ thực từ khoảng cách (đặt A = gốc)
        real_coords = self._compute_real_coords()
        if real_coords is None:
            return None

        # Pixel coordinates
        src_points = []
        dst_points = []

        for label in ["A", "B", "C", "D"]:
            if label in gcps and label in real_coords:
                src_points.append(gcps[label]["pixel"])
                dst_points.append(real_coords[label])

        if len(src_points) < 4:
            return None

        src = np.array(src_points, dtype=np.float32)
        dst = np.array(dst_points, dtype=np.float32)

        H, mask = cv2.findHomography(src, dst)
        return H

    def _compute_real_coords(self) -> dict:
        """Tính tọa độ thực (mét) từ 6 khoảng cách đo được"""
        d = self.distances
        if not d:
            return None

        # Đặt A = (0, 0)
        # B trên trục x: B = (AB, 0)
        AB = d.get("AB", 0)
        if AB == 0:
            return None

        coords = {"A": (0.0, 0.0), "B": (AB, 0.0)}

        # Tính C từ AC và BC (trilateration)
        AC = d.get("AC", 0)
        BC = d.get("BC", 0)
        if AC > 0 and BC > 0:
            cx = (AC ** 2 - BC ** 2 + AB ** 2) / (2 * AB)
            cy_sq = AC ** 2 - cx ** 2
            cy = np.sqrt(max(0, cy_sq))
            coords["C"] = (cx, cy)

        # Tính D từ AD và BD
        AD = d.get("AD", 0)
        BD = d.get("BD", 0)
        if AD > 0 and BD > 0:
            dx = (AD ** 2 - BD ** 2 + AB ** 2) / (2 * AB)
            dy_sq = AD ** 2 - dx ** 2
            dy = np.sqrt(max(0, dy_sq))
            # D có thể ở cùng phía hoặc khác phía C
            # Dùng CD để xác định
            CD = d.get("CD", 0)
            if "C" in coords and CD > 0:
                cx, cy = coords["C"]
                dist_pos = np.sqrt((dx - cx) ** 2 + (dy - cy) ** 2)
                dist_neg = np.sqrt((dx - cx) ** 2 + (-dy - cy) ** 2)
                if abs(dist_neg - CD) < abs(dist_pos - CD):
                    dy = -dy
            coords["D"] = (dx, dy)

        return coords
