"""
Module 6: AI Detector
Phát hiện người, phương tiện, vùng ngập trên ảnh drone

Input:  keyframes
Output: detections [{frame_id, objects: [{class, confidence, bbox, center}]}]
"""

import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm

# YOLO class mapping cho COCO
COCO_PERSON_CLASSES = [0]  # person
COCO_VEHICLE_CLASSES = [2, 3, 5, 7]  # car, motorcycle, bus, truck
COCO_BOAT_CLASSES = [8]  # boat

TARGET_MAP = {
    "person": COCO_PERSON_CLASSES,
    "car": [2], "truck": [7], "bus": [5], "motorcycle": [3],
    "boat": COCO_BOAT_CLASSES,
    "vehicle": COCO_VEHICLE_CLASSES,
}


class AIDetector:
    def __init__(self, config: dict):
        self.model_name = config.get("model", "yolov8s")
        self.confidence = config.get("confidence", 0.5)
        self.targets = config.get("targets", ["person"])
        self.flood_detection = config.get("flood_detection", False)
        self.use_tensorrt = config.get("use_tensorrt", True)
        self.model = None

    def _load_model(self):
        """Load YOLO model"""
        if self.model is not None:
            return

        try:
            from ultralytics import YOLO

            model_path = Path(__file__).parent.parent / "models" / f"{self.model_name}.pt"

            if not model_path.exists():
                print(f"  ⬇️  Tải model {self.model_name}...")
                model_path = self.model_name  # ultralytics tự tải

            self.model = YOLO(str(model_path))

            # Thử export TensorRT (Jetson)
            if self.use_tensorrt:
                try:
                    engine_path = Path(str(model_path).replace(".pt", ".engine"))
                    if not engine_path.exists():
                        print(f"  🔧 Export TensorRT engine (lần đầu, ~2-5 phút)...")
                        self.model.export(format="engine", half=True)
                    self.model = YOLO(str(engine_path))
                    print(f"  🚀 Dùng TensorRT engine")
                except Exception:
                    print(f"  ⚠️  TensorRT không khả dụng, dùng PyTorch")

            print(f"  🤖 Model loaded: {self.model_name}")

        except ImportError:
            print("  ❌ ultralytics chưa cài. Chạy: pip install ultralytics")
            raise

    def detect_all(self, frames: list) -> list:
        """Detect trên tất cả frames"""
        self._load_model()

        # Xác định COCO class IDs cần detect
        target_classes = set()
        for target in self.targets:
            if target in TARGET_MAP:
                target_classes.update(TARGET_MAP[target])

        detections = []

        for f in tqdm(frames, desc="  AI Detect", unit="frame"):
            frame_det = self._detect_frame(f, target_classes)
            detections.append(frame_det)

        # Flood detection (nếu bật)
        if self.flood_detection:
            print("  🌊 Detecting flood areas...")
            for i, f in enumerate(frames):
                flood_mask = self._detect_flood(f["image"])
                if flood_mask is not None:
                    detections[i]["flood_mask"] = flood_mask

        return detections

    def _detect_frame(self, frame: dict, target_classes: set) -> dict:
        """Detect objects trên 1 frame"""
        results = self.model(
            frame["image"],
            conf=self.confidence,
            verbose=False,
            classes=list(target_classes) if target_classes else None
        )

        objects = []
        for r in results:
            if r.boxes is None:
                continue

            for box in r.boxes:
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                x1, y1, x2, y2 = box.xyxy[0].tolist()

                # Map class ID → tên
                cls_name = r.names[cls_id] if cls_id in r.names else str(cls_id)

                objects.append({
                    "class": cls_name,
                    "class_id": cls_id,
                    "confidence": conf,
                    "bbox": [int(x1), int(y1), int(x2), int(y2)],
                    "center": [int((x1 + x2) / 2), int((y1 + y2) / 2)],
                })

        return {
            "frame_id": frame["frame_id"],
            "timestamp": frame.get("timestamp", 0),
            "objects": objects,
        }

    def _detect_flood(self, image: np.ndarray) -> np.ndarray:
        """
        Phát hiện vùng ngập nước bằng color segmentation.
        Nước thường có màu nâu đục (lũ) hoặc xanh đậm.
        """
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Mask 1: Nước đục (lũ) — nâu, low saturation
        lower_muddy = np.array([5, 30, 30])
        upper_muddy = np.array([25, 180, 180])
        mask_muddy = cv2.inRange(hsv, lower_muddy, upper_muddy)

        # Mask 2: Nước xanh — blue/cyan
        lower_blue = np.array([90, 30, 30])
        upper_blue = np.array([130, 255, 200])
        mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)

        # Combine
        water_mask = cv2.bitwise_or(mask_muddy, mask_blue)

        # Clean up
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        water_mask = cv2.morphologyEx(water_mask, cv2.MORPH_CLOSE, kernel)
        water_mask = cv2.morphologyEx(water_mask, cv2.MORPH_OPEN, kernel)

        # Chỉ giữ vùng lớn (>1% frame area)
        min_area = image.shape[0] * image.shape[1] * 0.01
        contours, _ = cv2.findContours(water_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        filtered_mask = np.zeros_like(water_mask)
        for cnt in contours:
            if cv2.contourArea(cnt) > min_area:
                cv2.drawContours(filtered_mask, [cnt], -1, 255, -1)

        return filtered_mask if np.any(filtered_mask) else None
