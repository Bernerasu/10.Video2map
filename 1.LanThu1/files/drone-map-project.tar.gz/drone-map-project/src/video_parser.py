"""
Module 1: Video Parser
Trích xuất keyframes từ video MP4

Input:  file video MP4
Output: danh sách frames [{image, timestamp, frame_id}, ...]
"""

import cv2
import numpy as np
from pathlib import Path
from tqdm import tqdm


class VideoParser:
    def __init__(self, config: dict):
        self.interval_sec = config.get("keyframe_interval_sec", 1.5)
        self.max_frames = config.get("max_frames", 500)
        self.resize_factor = config.get("resize_factor", 1.0)

    def extract_keyframes(self, video_path: str) -> list:
        """
        Trích xuất keyframes từ video.

        Returns:
            list of dict: [{
                "frame_id": int,
                "timestamp": float (seconds),
                "image": np.ndarray (BGR),
                "image_path": str (nếu lưu ra disk)
            }, ...]
        """
        cap = cv2.VideoCapture(video_path)

        if not cap.isOpened():
            raise ValueError(f"Không thể mở video: {video_path}")

        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        print(f"  Video: {width}x{height}, {fps:.1f}fps, {duration:.1f}s, {total_frames} frames")

        # Tính interval theo frame
        frame_interval = max(1, int(fps * self.interval_sec))
        estimated_keyframes = min(total_frames // frame_interval, self.max_frames)

        print(f"  Extract mỗi {self.interval_sec}s ({frame_interval} frames)")
        print(f"  Ước tính: ~{estimated_keyframes} keyframes")

        frames = []
        frame_count = 0

        pbar = tqdm(total=estimated_keyframes, desc="  Extracting", unit="frame")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % frame_interval == 0:
                timestamp = frame_count / fps

                # Resize nếu cần
                if self.resize_factor != 1.0:
                    new_w = int(width * self.resize_factor)
                    new_h = int(height * self.resize_factor)
                    frame = cv2.resize(frame, (new_w, new_h))

                frames.append({
                    "frame_id": len(frames),
                    "timestamp": timestamp,
                    "image": frame,
                    "original_frame_num": frame_count,
                })

                pbar.update(1)

                if len(frames) >= self.max_frames:
                    print(f"\n  ⚠️  Đạt giới hạn {self.max_frames} frames")
                    break

            frame_count += 1

        pbar.close()
        cap.release()

        # Tính blur score để filter frames kém chất lượng
        frames = self._filter_blurry(frames)

        return frames

    def _filter_blurry(self, frames: list, threshold: float = 50.0) -> list:
        """Loại bỏ frames bị blur (motion blur)"""
        scored_frames = []
        removed = 0

        for f in frames:
            gray = cv2.cvtColor(f["image"], cv2.COLOR_BGR2GRAY)
            blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
            f["blur_score"] = blur_score

            if blur_score >= threshold:
                scored_frames.append(f)
            else:
                removed += 1

        if removed > 0:
            print(f"  🔍 Loại bỏ {removed} frames bị blur (threshold={threshold})")

        return scored_frames

    @staticmethod
    def save_frames(frames: list, output_dir: str):
        """Lưu keyframes ra disk"""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        for f in frames:
            path = out / f"frame_{f['frame_id']:04d}.jpg"
            cv2.imwrite(str(path), f["image"], [cv2.IMWRITE_JPEG_QUALITY, 90])
            f["image_path"] = str(path)
