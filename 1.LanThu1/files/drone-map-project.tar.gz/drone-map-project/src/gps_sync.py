"""
Module 2: GPS Sync
Parse GPS data từ SRT (DJI), EXIF, CSV và sync với keyframes

Input:  frames + GPS file
Output: frames có thêm lat, lon, alt, heading
"""

import re
import csv
import os
from pathlib import Path


class GPSSync:
    def __init__(self, config: dict):
        self.source = config.get("source", "auto")
        self.datum = config.get("datum", "WGS84")
        self.alt_offset = config.get("altitude_offset", 0)

    def sync_from_file(self, frames: list, gps_path: str) -> list:
        """Đọc GPS từ file và gán cho frames theo timestamp"""
        ext = Path(gps_path).suffix.lower()

        if ext == ".srt":
            gps_data = self._parse_srt(gps_path)
        elif ext == ".csv":
            gps_data = self._parse_csv(gps_path)
        else:
            print(f"  ⚠️  Định dạng GPS không hỗ trợ: {ext}")
            return frames

        return self._match_gps_to_frames(frames, gps_data)

    def sync_from_video(self, frames: list, video_path: str) -> list:
        """Thử đọc GPS từ video metadata hoặc SRT cùng tên"""
        video = Path(video_path)

        # Tìm file SRT cùng tên
        srt_path = video.with_suffix(".SRT")
        if not srt_path.exists():
            srt_path = video.with_suffix(".srt")

        if srt_path.exists():
            print(f"  📄 Tìm thấy SRT: {srt_path}")
            return self.sync_from_file(frames, str(srt_path))

        # Thử đọc GPS từ video metadata (GoPro GPMF, DJI meta)
        gps_data = self._extract_gps_from_video(video_path)
        if gps_data:
            return self._match_gps_to_frames(frames, gps_data)

        print(f"  ⚠️  Không tìm thấy GPS data")
        return frames

    def _parse_srt(self, srt_path: str) -> list:
        """
        Parse DJI SRT subtitle file.
        Format DJI:
            1
            00:00:00,000 --> 00:00:00,033
            [iso: 400] [shutter: 1/120] ...
            [latitude: 10.7628] [longitude: 106.6602] [rel_alt: 50.0]
        """
        gps_data = []

        with open(srt_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Tìm tất cả blocks
        blocks = content.strip().split("\n\n")

        for block in blocks:
            lines = block.strip().split("\n")
            if len(lines) < 2:
                continue

            # Parse timestamp
            time_match = re.search(
                r"(\d{2}):(\d{2}):(\d{2}),(\d{3})", lines[1] if len(lines) > 1 else ""
            )
            if not time_match:
                continue

            h, m, s, ms = time_match.groups()
            timestamp = int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000

            # Parse GPS data từ toàn bộ block
            block_text = " ".join(lines)

            lat_match = re.search(r"\[latitude[:\s]+([-\d.]+)\]", block_text, re.I)
            lon_match = re.search(r"\[longitude[:\s]+([-\d.]+)\]", block_text, re.I)
            alt_match = re.search(r"\[(?:rel_)?alt(?:itude)?[:\s]+([-\d.]+)\]", block_text, re.I)
            heading_match = re.search(r"\[(?:compass_)?heading[:\s]+([-\d.]+)\]", block_text, re.I)

            if lat_match and lon_match:
                gps_data.append({
                    "timestamp": timestamp,
                    "lat": float(lat_match.group(1)),
                    "lon": float(lon_match.group(1)),
                    "alt": float(alt_match.group(1)) + self.alt_offset if alt_match else None,
                    "heading": float(heading_match.group(1)) if heading_match else None,
                })

        print(f"  📡 Parse SRT: {len(gps_data)} GPS points")
        return gps_data

    def _parse_csv(self, csv_path: str) -> list:
        """
        Parse CSV GPS file.
        Expected columns: timestamp, lat, lon, alt, heading
        """
        gps_data = []

        with open(csv_path, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                gps_data.append({
                    "timestamp": float(row.get("timestamp", 0)),
                    "lat": float(row.get("lat", 0)),
                    "lon": float(row.get("lon", 0)),
                    "alt": float(row.get("alt", 0)) + self.alt_offset if "alt" in row else None,
                    "heading": float(row.get("heading", 0)) if "heading" in row else None,
                })

        print(f"  📡 Parse CSV: {len(gps_data)} GPS points")
        return gps_data

    def _extract_gps_from_video(self, video_path: str) -> list:
        """Thử extract GPS từ video metadata (GoPro GPMF, etc.)"""
        # TODO: Implement GoPro GPMF parser
        # TODO: Implement DJI video metadata parser
        return []

    def _match_gps_to_frames(self, frames: list, gps_data: list) -> list:
        """Gán GPS cho frames bằng interpolation theo timestamp"""
        if not gps_data:
            return frames

        matched = 0
        for frame in frames:
            ts = frame["timestamp"]

            # Tìm 2 GPS points gần nhất (trước và sau timestamp)
            before = None
            after = None

            for gps in gps_data:
                if gps["timestamp"] <= ts:
                    before = gps
                elif after is None:
                    after = gps
                    break

            if before and after:
                # Linear interpolation
                t_range = after["timestamp"] - before["timestamp"]
                if t_range > 0:
                    ratio = (ts - before["timestamp"]) / t_range
                    frame["lat"] = before["lat"] + (after["lat"] - before["lat"]) * ratio
                    frame["lon"] = before["lon"] + (after["lon"] - before["lon"]) * ratio
                    if before.get("alt") and after.get("alt"):
                        frame["alt"] = before["alt"] + (after["alt"] - before["alt"]) * ratio
                    if before.get("heading") and after.get("heading"):
                        frame["heading"] = before["heading"] + (after["heading"] - before["heading"]) * ratio
                    matched += 1
            elif before:
                frame["lat"] = before["lat"]
                frame["lon"] = before["lon"]
                frame["alt"] = before.get("alt")
                frame["heading"] = before.get("heading")
                matched += 1

        print(f"  🔗 GPS match: {matched}/{len(frames)} frames")
        return frames
