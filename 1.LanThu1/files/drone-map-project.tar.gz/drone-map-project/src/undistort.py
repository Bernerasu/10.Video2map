"""
Module 3: Camera Undistort
Sửa méo lens (barrel distortion) cho camera drone

Input:  frames + camera calibration profile
Output: frames đã sửa méo
"""

import cv2
import numpy as np
import yaml
import os
from pathlib import Path


# Calibration profiles tích hợp sẵn cho camera phổ biến
BUILTIN_PROFILES = {
    "dji_mini4_wide": {
        "camera_matrix": [[2676, 0, 960], [0, 2676, 540], [0, 0, 1]],
        "dist_coeffs": [-0.28, 0.08, 0.0, 0.0, -0.01],
        "resolution": [1920, 1080]
    },
    "gopro_hero12_wide": {
        "camera_matrix": [[1600, 0, 960], [0, 1600, 540], [0, 0, 1]],
        "dist_coeffs": [-0.35, 0.12, 0.0, 0.0, -0.02],
        "resolution": [1920, 1080]
    },
    "generic_wide": {
        "camera_matrix": [[2000, 0, 960], [0, 2000, 540], [0, 0, 1]],
        "dist_coeffs": [-0.30, 0.09, 0.0, 0.0, -0.01],
        "resolution": [1920, 1080]
    }
}


class CameraUndistort:
    def __init__(self, config: dict):
        self.profile_name = config.get("profile", "auto")
        self.camera_matrix = None
        self.dist_coeffs = None
        self.new_camera_matrix = None
        self._loaded = False

    def _load_profile(self, frame_shape: tuple):
        """Load calibration profile"""
        h, w = frame_shape[:2]

        if self.profile_name == "auto":
            # Dùng generic profile, scale theo resolution
            profile = BUILTIN_PROFILES["generic_wide"]
            print(f"  📷 Camera profile: generic_wide (auto)")
        elif self.profile_name in BUILTIN_PROFILES:
            profile = BUILTIN_PROFILES[self.profile_name]
            print(f"  📷 Camera profile: {self.profile_name}")
        else:
            # Load từ file YAML
            profile_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "config", "camera_profiles", f"{self.profile_name}.yaml"
            )
            if os.path.exists(profile_path):
                with open(profile_path) as f:
                    profile = yaml.safe_load(f)
                print(f"  📷 Camera profile: {profile_path}")
            else:
                print(f"  ⚠️  Profile không tìm thấy: {self.profile_name}, dùng generic")
                profile = BUILTIN_PROFILES["generic_wide"]

        # Scale camera matrix theo resolution thực tế
        orig_w, orig_h = profile["resolution"]
        scale_x = w / orig_w
        scale_y = h / orig_h

        mtx = np.array(profile["camera_matrix"], dtype=np.float64)
        mtx[0] *= scale_x  # fx, cx
        mtx[1] *= scale_y  # fy, cy

        self.camera_matrix = mtx
        self.dist_coeffs = np.array(profile["dist_coeffs"], dtype=np.float64)

        # Tính optimal camera matrix
        self.new_camera_matrix, _ = cv2.getOptimalNewCameraMatrix(
            self.camera_matrix, self.dist_coeffs, (w, h), 1, (w, h)
        )

        self._loaded = True

    def process(self, frames: list) -> list:
        """Undistort tất cả frames"""
        if not frames:
            return frames

        # Load profile dựa trên kích thước frame đầu tiên
        if not self._loaded:
            self._load_profile(frames[0]["image"].shape)

        for f in frames:
            f["image"] = cv2.undistort(
                f["image"],
                self.camera_matrix,
                self.dist_coeffs,
                None,
                self.new_camera_matrix
            )

        return frames
