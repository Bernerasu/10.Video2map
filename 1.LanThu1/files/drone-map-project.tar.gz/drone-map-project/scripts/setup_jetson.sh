#!/bin/bash
# ============================================================
# DroneMap — Setup Script cho Jetson Orin Nano Super
# Chạy: sudo ./scripts/setup_jetson.sh
# Thời gian: ~10-15 phút
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# ------------------------------------------------------------
# Kiểm tra hệ thống
# ------------------------------------------------------------
log_info "Kiểm tra hệ thống..."

if [ "$(id -u)" -ne 0 ]; then
    log_error "Cần chạy với sudo: sudo ./scripts/setup_jetson.sh"
    exit 1
fi

# Detect platform
if [ -f /etc/nv_tegra_release ]; then
    log_info "Phát hiện Jetson platform"
    IS_JETSON=true
else
    log_warn "Không phải Jetson — cài đặt chế độ tương thích (CPU only)"
    IS_JETSON=false
fi

TOTAL_RAM=$(free -m | awk '/^Mem:/{print $2}')
log_info "RAM: ${TOTAL_RAM} MB"

if [ "$TOTAL_RAM" -lt 7000 ]; then
    log_warn "RAM < 8GB — hiệu năng có thể bị hạn chế"
fi

# ------------------------------------------------------------
# Cập nhật hệ thống
# ------------------------------------------------------------
log_info "Cập nhật hệ thống..."
apt-get update -qq
apt-get upgrade -y -qq

# ------------------------------------------------------------
# Cài đặt system packages
# ------------------------------------------------------------
log_info "Cài đặt system packages..."
apt-get install -y -qq \
    python3-pip \
    python3-dev \
    python3-venv \
    ffmpeg \
    libgdal-dev \
    gdal-bin \
    nginx \
    sqlite3 \
    libsqlite3-dev \
    wget \
    curl \
    git \
    htop \
    v4l-utils \
    gstreamer1.0-tools \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-ugly

# ------------------------------------------------------------
# Setup Python virtual environment
# ------------------------------------------------------------
log_info "Tạo Python virtual environment..."
VENV_DIR="${PROJECT_DIR}/venv"

python3 -m venv --system-site-packages "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# ------------------------------------------------------------
# Cài đặt Python packages
# ------------------------------------------------------------
log_info "Cài đặt Python packages..."
pip install --upgrade pip setuptools wheel

pip install \
    numpy \
    pyyaml \
    flask \
    flask-socketio \
    gevent \
    pillow \
    tqdm \
    pyproj \
    shapely

# OpenCV — dùng bản có sẵn trên Jetson nếu có
if $IS_JETSON; then
    log_info "Jetson detected — sử dụng OpenCV có sẵn từ JetPack"
    # JetPack đã cài OpenCV với CUDA support
    # Chỉ cần symlink vào venv
    OPENCV_PATH=$(python3 -c "import cv2; print(cv2.__file__)" 2>/dev/null || echo "")
    if [ -z "$OPENCV_PATH" ]; then
        log_warn "OpenCV chưa có — cài từ pip (không có CUDA)"
        pip install opencv-python-headless
    fi
else
    pip install opencv-python-headless
fi

# GDAL Python bindings
GDAL_VERSION=$(gdal-config --version)
pip install "GDAL==${GDAL_VERSION}"

# AI models (ultralytics YOLOv8)
pip install ultralytics

# ------------------------------------------------------------
# Tải AI models
# ------------------------------------------------------------
log_info "Tải AI models..."
MODELS_DIR="${PROJECT_DIR}/models"
mkdir -p "$MODELS_DIR"

# YOLOv8 small — person + vehicle detection
if [ ! -f "${MODELS_DIR}/yolov8s.pt" ]; then
    log_info "Tải YOLOv8s model..."
    cd "$MODELS_DIR"
    python3 -c "from ultralytics import YOLO; YOLO('yolov8s.pt')"
    cd "$PROJECT_DIR"
fi

# ------------------------------------------------------------
# Cấu hình swap (quan trọng cho 8GB RAM)
# ------------------------------------------------------------
if $IS_JETSON; then
    log_info "Cấu hình swap cho Jetson 8GB..."
    SWAP_SIZE=8  # 8GB swap

    if [ ! -f /swapfile ]; then
        fallocate -l ${SWAP_SIZE}G /swapfile
        chmod 600 /swapfile
        mkswap /swapfile
        swapon /swapfile
        echo '/swapfile none swap sw 0 0' >> /etc/fstab
        log_info "Đã tạo ${SWAP_SIZE}GB swap"
    else
        log_info "Swap đã tồn tại"
    fi

    # Tối ưu memory
    echo 'vm.swappiness=10' >> /etc/sysctl.conf
    sysctl -p
fi

# ------------------------------------------------------------
# Cấu hình Nginx
# ------------------------------------------------------------
log_info "Cấu hình Nginx..."
cat > /etc/nginx/sites-available/dronemap << 'NGINX_CONF'
server {
    listen 8080;
    server_name _;

    # Tile serving — static files, rất nhanh
    location /tiles/ {
        alias /opt/dronemap/output/tiles/;
        expires 1h;
        add_header Cache-Control "public, immutable";
        add_header Access-Control-Allow-Origin "*";
    }

    # GeoJSON detections
    location /detections/ {
        alias /opt/dronemap/output/detections/;
        add_header Content-Type "application/json";
        add_header Access-Control-Allow-Origin "*";
    }

    # Web frontend
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
NGINX_CONF

ln -sf /etc/nginx/sites-available/dronemap /etc/nginx/sites-enabled/dronemap
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

# ------------------------------------------------------------
# Tạo thư mục output
# ------------------------------------------------------------
OUTPUT_DIR="/opt/dronemap/output"
mkdir -p "${OUTPUT_DIR}"/{tiles,detections,frames,mosaic}
chown -R $SUDO_USER:$SUDO_USER "${OUTPUT_DIR}"
ln -sf "${OUTPUT_DIR}" "${PROJECT_DIR}/output"

# ------------------------------------------------------------
# Tạo OSM offline directory
# ------------------------------------------------------------
OSM_DIR="/opt/dronemap/osm_data"
mkdir -p "$OSM_DIR"
log_info "Thư mục OSM offline: ${OSM_DIR}"
log_info "Tải OSM data cho Việt Nam: xem docs/SETUP_OSM.md"

# ------------------------------------------------------------
# Tối ưu Jetson power mode
# ------------------------------------------------------------
if $IS_JETSON; then
    log_info "Đặt Jetson power mode: MAXN (hiệu năng tối đa)..."
    nvpmodel -m 0 2>/dev/null || log_warn "Không thể đặt power mode"
    jetson_clocks 2>/dev/null || log_warn "Không thể set jetson_clocks"
fi

# ------------------------------------------------------------
# Tạo systemd service (tự động chạy web server)
# ------------------------------------------------------------
log_info "Tạo systemd service..."
cat > /etc/systemd/system/dronemap-web.service << EOF
[Unit]
Description=DroneMap Web Server
After=network.target nginx.service

[Service]
Type=simple
User=$SUDO_USER
WorkingDirectory=${PROJECT_DIR}
ExecStart=${VENV_DIR}/bin/python3 src/web_server.py
Restart=always
RestartSec=5
Environment=DRONEMAP_OUTPUT=${OUTPUT_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable dronemap-web

# ------------------------------------------------------------
# Hoàn tất
# ------------------------------------------------------------
echo ""
echo "============================================================"
log_info "✅ Cài đặt hoàn tất!"
echo "============================================================"
echo ""
echo "  Bước tiếp theo:"
echo ""
echo "  1. Kích hoạt môi trường:"
echo "     source venv/bin/activate"
echo ""
echo "  2. Xử lý video:"
echo "     python3 src/pipeline.py --video /path/to/video.mp4"
echo ""
echo "  3. Xem bản đồ:"
echo "     Mở trình duyệt → http://$(hostname -I | awk '{print $1}'):8080"
echo ""
echo "  4. Khởi động web server (tự động sau reboot):"
echo "     sudo systemctl start dronemap-web"
echo ""
echo "============================================================"
