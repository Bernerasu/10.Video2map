"""
Video2Map - Web Map Server
FastAPI serve tiles + Leaflet.js hiển thị bản đồ

Chạy:
  python3 web_server.py
  → Mở browser: http://192.168.88.123:8000

Tính năng:
  - Hiển thị map tiles từ panorama drone
  - Overlay lên OpenStreetMap (base layer)
  - GPS track hiển thị đường bay
  - Zoom / pan
  - Metadata info
"""

import os
import json
import uvicorn
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles


# ============================================================
# CONFIG
# ============================================================

TILES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output", "tiles")
GPS_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output", "keyframes", "gps_log.csv")
PANORAMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output", "panorama.jpg")
HOST = "0.0.0.0"
PORT = 8000


# ============================================================
# FASTAPI APP
# ============================================================

app = FastAPI(title="Video2Map", version="0.1.0")


# ============================================================
# API ROUTES
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def index():
    """Trang chính — hiển thị bản đồ"""
    
    # Đọc metadata
    meta_path = os.path.join(TILES_DIR, "metadata.json")
    if os.path.isfile(meta_path):
        with open(meta_path) as f:
            meta = json.load(f)
    else:
        meta = {
            "center": [10.8320, 106.8195],
            "zoom_min": 15,
            "zoom_max": 19,
            "bounds": [[10.830, 106.817], [10.834, 106.822]],
        }
    
    # Đọc GPS track
    gps_track = []
    if os.path.isfile(GPS_LOG):
        with open(GPS_LOG) as f:
            lines = f.readlines()[1:]  # skip header
            for line in lines:
                parts = line.strip().split(",")
                if len(parts) >= 3:
                    gps_track.append([float(parts[1]), float(parts[2])])
    
    center = meta["center"]
    zoom_min = meta.get("zoom_min", 15)
    zoom_max = meta.get("zoom_max", 19)
    bounds = meta.get("bounds", [[10.830, 106.817], [10.834, 106.822]])
    
    html = f"""<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video2Map — Bản đồ từ Drone</title>
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        
        body {{ font-family: 'Segoe UI', Arial, sans-serif; }}
        
        #map {{ 
            width: 100%; 
            height: 100vh; 
        }}
        
        .info-panel {{
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1000;
            background: rgba(0, 0, 0, 0.85);
            color: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            font-size: 13px;
            line-height: 1.6;
            min-width: 220px;
            backdrop-filter: blur(10px);
        }}
        
        .info-panel h3 {{
            color: #4CAF50;
            margin-bottom: 8px;
            font-size: 16px;
        }}
        
        .info-panel .label {{
            color: #aaa;
        }}
        
        .info-panel .value {{
            color: #fff;
            font-weight: 600;
        }}
        
        .status {{
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            background: rgba(0, 0, 0, 0.75);
            color: #4CAF50;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }}
        
        .layer-toggle {{
            position: absolute;
            top: 10px;
            left: 55px;
            z-index: 1000;
            background: rgba(0, 0, 0, 0.85);
            color: #fff;
            padding: 10px 15px;
            border-radius: 10px;
            font-size: 12px;
        }}
        
        .layer-toggle label {{
            display: block;
            margin: 4px 0;
            cursor: pointer;
        }}
        
        .layer-toggle input {{
            margin-right: 6px;
        }}
    </style>
</head>
<body>
    <div id="map"></div>
    
    <!-- Info Panel -->
    <div class="info-panel">
        <h3>🛸 Video2Map</h3>
        <div>
            <span class="label">Tọa độ:</span>
            <span class="value" id="coord">—</span>
        </div>
        <div>
            <span class="label">Zoom:</span>
            <span class="value" id="zoom-level">—</span>
        </div>
        <div>
            <span class="label">GPS points:</span>
            <span class="value">{len(gps_track)}</span>
        </div>
        <div>
            <span class="label">Tiles:</span>
            <span class="value">{meta.get('total_tiles', '—')}</span>
        </div>
    </div>
    
    <!-- Layer Toggle -->
    <div class="layer-toggle">
        <strong>Layers</strong>
        <label><input type="checkbox" id="toggle-drone" checked> Drone Map</label>
        <label><input type="checkbox" id="toggle-osm" checked> OpenStreetMap</label>
        <label><input type="checkbox" id="toggle-track" checked> GPS Track</label>
    </div>
    
    <!-- Status -->
    <div class="status">
        Video2Map v0.1 — Jetson Orin Nano | Bản đồ từ drone video
    </div>
    
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    
    <script>
        // === Map Init ===
        const map = L.map('map', {{
            center: [{center[0]}, {center[1]}],
            zoom: {zoom_max - 1},
            minZoom: 5,
            maxZoom: 22,
        }});
        
        // === Base Layer: OpenStreetMap ===
        const osmLayer = L.tileLayer('https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
            maxZoom: 22,
            attribution: '&copy; OpenStreetMap contributors'
        }}).addTo(map);
        
        // === Drone Tiles Layer ===
        const droneTiles = L.tileLayer('/tiles/{{z}}/{{x}}/{{y}}.png', {{
            minZoom: {zoom_min},
            maxZoom: {zoom_max},
            opacity: 0.9,
            attribution: 'Video2Map — Drone Mapping',
            errorTileUrl: '',
        }}).addTo(map);
        
        // === GPS Track ===
        const gpsTrack = {json.dumps(gps_track)};
        
        let trackLayer = null;
        if (gpsTrack.length > 0) {{
            trackLayer = L.polyline(gpsTrack, {{
                color: '#FF5722',
                weight: 3,
                opacity: 0.8,
                dashArray: '10, 5',
            }}).addTo(map);
            
            // Markers đầu/cuối
            L.circleMarker(gpsTrack[0], {{
                radius: 6, color: '#4CAF50', fillColor: '#4CAF50', 
                fillOpacity: 1, weight: 2
            }}).addTo(map).bindPopup('🛫 Bắt đầu');
            
            L.circleMarker(gpsTrack[gpsTrack.length - 1], {{
                radius: 6, color: '#f44336', fillColor: '#f44336', 
                fillOpacity: 1, weight: 2
            }}).addTo(map).bindPopup('🛬 Kết thúc');
        }}
        
        // === Bounds Rectangle ===
        const bounds = L.latLngBounds(
            [{bounds[0][0]}, {bounds[0][1]}],
            [{bounds[1][0]}, {bounds[1][1]}]
        );
        
        L.rectangle(bounds, {{
            color: '#2196F3', weight: 1, 
            fillOpacity: 0, dashArray: '5, 5'
        }}).addTo(map);
        
        // === Fit to bounds ===
        map.fitBounds(bounds, {{ padding: [50, 50] }});
        
        // === Events ===
        map.on('mousemove', function(e) {{
            document.getElementById('coord').textContent = 
                e.latlng.lat.toFixed(6) + ', ' + e.latlng.lng.toFixed(6);
        }});
        
        map.on('zoomend', function() {{
            document.getElementById('zoom-level').textContent = map.getZoom();
        }});
        
        document.getElementById('zoom-level').textContent = map.getZoom();
        
        // === Layer Toggles ===
        document.getElementById('toggle-drone').addEventListener('change', function() {{
            this.checked ? map.addLayer(droneTiles) : map.removeLayer(droneTiles);
        }});
        
        document.getElementById('toggle-osm').addEventListener('change', function() {{
            this.checked ? map.addLayer(osmLayer) : map.removeLayer(osmLayer);
        }});
        
        document.getElementById('toggle-track').addEventListener('change', function() {{
            if (trackLayer) {{
                this.checked ? map.addLayer(trackLayer) : map.removeLayer(trackLayer);
            }}
        }});
    </script>
</body>
</html>"""
    
    return HTMLResponse(content=html)


@app.get("/tiles/{{z}}/{{x}}/{{y}}.png")
async def get_tile(z: int, x: int, y: int):
    """Serve map tile"""
    tile_path = os.path.join(TILES_DIR, str(z), str(x), f"{y}.png")
    
    if os.path.isfile(tile_path):
        return FileResponse(tile_path, media_type="image/png")
    
    # Trả về transparent tile nếu không có
    raise HTTPException(status_code=404)


@app.get("/api/metadata")
async def get_metadata():
    """API metadata"""
    meta_path = os.path.join(TILES_DIR, "metadata.json")
    if os.path.isfile(meta_path):
        with open(meta_path) as f:
            return JSONResponse(json.load(f))
    return JSONResponse({"error": "No metadata"}, status_code=404)


@app.get("/api/gps")
async def get_gps():
    """API GPS track"""
    if not os.path.isfile(GPS_LOG):
        return JSONResponse({"track": []})
    
    track = []
    with open(GPS_LOG) as f:
        lines = f.readlines()[1:]
        for line in lines:
            parts = line.strip().split(",")
            if len(parts) >= 4:
                track.append({
                    "lat": float(parts[1]),
                    "lon": float(parts[2]),
                    "time": float(parts[3]),
                })
    
    return JSONResponse({"track": track, "total": len(track)})


@app.get("/panorama.jpg")
async def get_panorama():
    """Download panorama gốc"""
    if os.path.isfile(PANORAMA_PATH):
        return FileResponse(PANORAMA_PATH, media_type="image/jpeg")
    raise HTTPException(status_code=404)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    print(f"{'='*60}")
    print(f"Video2Map — Web Map Server")
    print(f"{'='*60}")
    print(f"  Tiles: {TILES_DIR}")
    print(f"  GPS:   {GPS_LOG}")
    print(f"  Server: http://{HOST}:{PORT}")
    print(f"  LAN:    http://192.168.88.123:{PORT}")
    print(f"{'='*60}\n")
    
    # Kiểm tra tiles tồn tại
    if not os.path.isdir(TILES_DIR):
        print("⚠️  Chưa có tiles! Chạy georef_tiles.py trước.")
        print("    python3 src/georef_tiles.py")
    else:
        meta_path = os.path.join(TILES_DIR, "metadata.json")
        if os.path.isfile(meta_path):
            with open(meta_path) as f:
                meta = json.load(f)
            print(f"  Tiles: {meta.get('total_tiles', '?')} tiles")
            print(f"  Center: {meta.get('center', '?')}")
    
    print()
    uvicorn.run(app, host=HOST, port=PORT)
